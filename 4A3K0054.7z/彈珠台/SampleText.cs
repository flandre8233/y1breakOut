﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace 彈珠台
{
    class SampleText
    {
        public void Draw(Graphics G)
        {
            
        }
        public void Update()
        {

        }
    }
}
